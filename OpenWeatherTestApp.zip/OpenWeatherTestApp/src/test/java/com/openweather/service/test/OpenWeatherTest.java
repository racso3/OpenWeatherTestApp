package com.openweather.service.test;

import static com.jayway.restassured.RestAssured.expect;
import static com.jayway.restassured.RestAssured.get;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.junit.Test;

import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.openweather.util.ParseUtil;

public class OpenWeatherTest {

	@Test
	public void testGetCityNameById() throws JSONException {
		
		//make get request to fetch city's data
		Response resp = get("http://api.openweathermap.org/data/2.5/weather?id=2172797&appid=2de143494c0b295cca9337e1e96b00e0");
		
		//Fetching response in JSON
		JSONArray jsonResponse = new JSONArray("[" + resp.asString() + "]");
		
		//Fetching value of city's name parameter
		String city = jsonResponse.getJSONObject(0).getString("name");
		
		//Asserting that name of the City is Cairns
		assertNotNull(jsonResponse);
		assertEquals(city, "Cairns");
	}

	
	@Test
	public void testNegativeGetCityNameById() throws JSONException {
		
		//make get request to fetch city's data
		Response resp = get("http://api.openweathermap.org/data/2.5/weather?id=2172797&appid=2de143494c0b295cca9337e1e96b00e0");
		
		//Fetching response in JSON
		JSONArray jsonResponse = new JSONArray("[" + resp.asString() + "]");
		
		//Fetching value of city's name parameter
		String city = jsonResponse.getJSONObject(0).getString("name");
		
		//Asserting that name of the City should not be empty
		assertNotSame(city, "");
	}
	
	
	@Test
	public void testGetAllCitiesById() throws JSONException, IOException {
			
		//Reads the .dat file that contain the list of methods to scan in our existing Json files.
		String[] line;
		String baseURI = "http://api.openweathermap.org/data/2.5/weather?id=";
		String uriSuffix = "&appid=2de143494c0b295cca9337e1e96b00e0";
		String appPath = new File(".").getCanonicalPath();
		String resourcesPath = appPath + "\\src\\main\\resources\\";
		String inputMethodsFile = resourcesPath + "cities.dat";
		Scanner in = new Scanner(new FileReader(inputMethodsFile));
		ParseUtil readConfigFile = new ParseUtil();
		
		while (in.hasNextLine()) {
			line = readConfigFile.getLineOperation(in.nextLine());
			
			//make get request to fetch city's data
			Response resp = get(baseURI + line[0].substring(7, line[0].length()) + uriSuffix);

			//Fetching response in JSON
			JSONArray jsonResponse = new JSONArray("[" + resp.asString() + "]");
			
			//Fetching value of city's name parameter
			String city = jsonResponse.getJSONObject(0).getString("name");
			
			//Asserting that name of the City should not be empty
			assertEquals(city, line[1].substring(8, line[1].length()-1));
		}
	}

	
	@Test
	public void testWeatherDataByZipCode() {
		Response res = get("http://api.openweathermap.org/data/2.5/weather?zip=94040,us&appid=2de143494c0b295cca9337e1e96b00e0");
		String json = res.asString();
		JsonPath jp = new JsonPath(json);
		
		//Asserting response code is OK
		assertEquals(200, res.getStatusCode());
		
		//Asserting longitude and latitude coordinates are not null
		assertNotNull(jp.get("coord.lon"));
		assertNotNull(jp.get("coord.lat"));
	}
	
	
	@Test
	public void testBadRequest() {
		expect().statusCode(401).when().get("http://api.openweathermap.org/data/2.5/weather?id=7839542");
	}

	
	@Test
	public void testReturnedHeaders() {
		expect().headers("Content-Type", "foo", "Content-Type", "application/json; charset=utf-8").when()
				.get("http://api.openweathermap.org/data/2.5/weather?zip=94040,us&appid=2de143494c0b295cca9337e1e96b00e0");
	}

}
