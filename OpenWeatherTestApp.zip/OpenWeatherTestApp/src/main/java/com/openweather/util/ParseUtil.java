package com.openweather.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ParseUtil {

	public String[] getLineOperation(String lineToSplit) {
		String[] split = lineToSplit.split(",");
		return split;
	}
	
	
	//Adds Json element to the array and prints it.
	public JSONArray constructArray(JSONArray jsonArray, String step) throws IOException, JSONException {
		JSONObject jsonObj = new JSONObject(step);
		jsonArray.put(jsonObj);
		return jsonArray;
	}
		
		
	//Reads input file
	public String readFile(String filepath) {
		StringBuilder sb = new StringBuilder();
		InputStream in = null;
		try {
			    in = new FileInputStream(new File(filepath));
				BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(in));
				if (bufferedReader != null) {
					int cp;
					while ((cp = bufferedReader.read()) != -1) {
						sb.append((char) cp);
					}
					bufferedReader.close();
				}
		in.close();
		} catch (Exception e) {
			throw new RuntimeException("Exception while calling path:"+ filepath, e);
		} 
		return sb.toString();
	}
		
		
	//Inserts Json element to the array at the specified position and prints it.
	public void insertJsonIntoArray(String jsonString, String step, int insertOrder, String testSuitePrefix) throws IOException {
		try {
		    JSONArray jsonArray = new JSONArray(jsonString);
		    JSONObject jsonObj = new JSONObject(step);
		    Object temp = jsonArray.get(insertOrder);
		    jsonArray.put(insertOrder, jsonObj);
		    jsonArray.put(insertOrder + 1, temp);
 
		    printJsonArray(jsonArray);
		    saveJsonFile(jsonArray, "C:\\Temp\\newFile.json", testSuitePrefix, "updated");
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
		
		
	//Adds Json element to the array and prints it.
	public void addJsonToArray(String jsonString, String step, String testSuitePrefix) throws IOException {
		try {
		    JSONArray jsonArray = new JSONArray(jsonString);
		    JSONObject jsonObj = new JSONObject(step);
		    jsonArray.put(jsonObj);
		    
		    printJsonArray(jsonArray);
		    saveJsonFile(jsonArray, "C:\\Temp\\newFile.json", testSuitePrefix, "updated");
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
		
	
	//Prints the array elements.
	public void printArrayElements(String jsonString) {
		try {
			JSONArray jsonArray = new JSONArray(jsonString);
			printJsonArray(jsonArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
		
		
	//print Json Array
	public void printJsonArray(JSONArray jsonArray) {
		int count = jsonArray.length(); // get totalCount of all jsonObjects
		for(int i=0 ; i< count; i++) { 
			JSONObject jsonObject;
			try {
				jsonObject = jsonArray.getJSONObject(i);
				System.out.println("jsonObject " + i + ": " + jsonObject);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		System.out.println();
	}
	
	
	//Extracts Step From Json Array
	public String extractStepFromJsonFile(JSONArray jsonArray, String step) throws IOException, JSONException {
		for (int i=0; i<jsonArray.length(); i++) {
			JSONObject obj = jsonArray.getJSONObject(i);
			if (obj.toString().contains(step)) {
    			return obj.toString();
    		}
    	}
		return null;
	}
	
	
	//Extracts Step From Json Array
	public String extractStepFromJsonFile(JSONArray jsonArray, String step, String comment) throws IOException, JSONException {
		for (int i=0; i<jsonArray.length(); i++) {
			JSONObject obj = jsonArray.getJSONObject(i);
    	    if (obj.toString().contains(step)) {
    	    	obj.put("description", "Delete Test Object. (To be deleted)");
    	    	return obj.toString();
    	    }
    	}
		return null;
	}
		
	
	//Creates a valid Array Json String so it can be manipulated step by step.
	public String getResponseChecksJsonString(String originalFilePath) {
		String jsonString = readFile(originalFilePath);
		//Remove prefix and suffix in order to parse Json Array of Response Checks.
		jsonString = jsonString.substring(jsonString.indexOf("responseChecks\":") + 16, jsonString.length() - 2);
		return jsonString;
	}
		
		
	//Creates a valid Json String with all the TestOps.
	public String getTestOpsJsonString(String originalFilePath) {
		String jsonString = readFile(originalFilePath);
		//Remove prefix and suffix in order to parse Json Array.
		jsonString = jsonString.substring(jsonString.indexOf("testOps\":") + 9, jsonString.indexOf("],") + 1);
		return jsonString;
	}
		
		
	//save Json File
	public void saveJsonFile(JSONArray jsonArray, String path, String testSuitePrefix, String fileName) throws IOException, JSONException {
		FileWriter file = new FileWriter(path);
        try {
        	file.write(testSuitePrefix + "[");
        	
        	for (int i=0; i<jsonArray.length(); i++) {
        	    JSONObject obj = jsonArray.getJSONObject(i);
        		file.write(obj.toString());
        		if (i != jsonArray.length()-1) {
        			file.write(",");
        		}
        	}
        	
        	file.write("]}");
            System.out.println("\n\nJSON File: \"" + fileName + "\" was generated successfully at: " + path);
 
        } catch (IOException e) {
            e.printStackTrace();
 
        } finally {
            file.flush();
            file.close();
        }
	}
	
	
	//Get Path Method
	public String getPathMethod(String originalFilePath) throws JSONException {
		JSONObject jSONobject = new JSONObject(readFile(originalFilePath));
		return jSONobject.get("path").toString();
	}
}